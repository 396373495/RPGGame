package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.DefaultButtonModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class Varietyshop {

	public static void main() {
		// TODO Auto-generated method stub
		Varietyshop varf = new Varietyshop();
		varf.initUI();
	}

	private JRadioButton v_commodity1;
	private JRadioButton v_commodity2;
	private JLabel v_commodity_explain1,v_commodity_explain2;
	static JFrame varf;

	private void initUI() {
		// TODO Auto-generated method stub
		varf = new JFrame();
		varf.setTitle("ǿ��֮·");
		varf.setSize(500,400);
		varf.setLocation(400, 300);
		
		//�߿򲼾ֹ���������
        varf.setLayout(new BorderLayout());
        varf.add(newNorthPanel(),BorderLayout.NORTH);
        varf.add(newWesthPanel(),BorderLayout.WEST);
        varf.add(newCenterPanel(),BorderLayout.CENTER);
        varf.add(newEasthPanel(),BorderLayout.EAST);
        varf.add(newSouthPanel(),BorderLayout.SOUTH);
		
		varf.setDefaultCloseOperation(3);
		varf.setVisible(true);
	}

	private Component newNorthPanel() {
		// TODO Auto-generated method stub
		JPanel northPanel = new JPanel();
		JLabel biaoti = new JLabel("�ӻ���");
        biaoti.setForeground(new Color(0,255,0));
        biaoti.setFont(new Font("",Font.BOLD,30));
        biaoti.setHorizontalAlignment(JLabel.CENTER);
       
        northPanel.setOpaque(false);
        
        northPanel.add(biaoti);
        
        return northPanel;
	}

	private Component newWesthPanel() {
		// TODO Auto-generated method stub
		JPanel westPanel = new JPanel();
		//����С
		westPanel.setPreferredSize(new Dimension(50,80));
		westPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		JLabel commodity_catalog = new JLabel("��Ʒ��");
		v_commodity1 = new JRadioButton("��ҩ");
		v_commodity2 = new JRadioButton("ҩ��");
		ButtonGroup v_commodity = new ButtonGroup(); 
		v_commodity.add(v_commodity1);
		v_commodity.add(v_commodity2);
		westPanel.setOpaque(false);
		westPanel.add(commodity_catalog);
		westPanel.add(v_commodity1);
		westPanel.add(v_commodity2);
		
		v_commodity1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				v_commodity_explain1.setText("HP+10");
				v_commodity_explain2.setText("MP+5");
			}
			
		});
		
		v_commodity2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				v_commodity_explain1.setText("HP+20");
				v_commodity_explain2.setText("MP+55555555");
			}
			
		});

		return westPanel;
	}
	
	private Component newCenterPanel() {
		// TODO Auto-generated method stub
		JPanel centerPanel = new JPanel();
		centerPanel.setPreferredSize(new Dimension(0,0));
		
		ImageIcon varietyshop_image = new ImageIcon("./pic/sd1.jpg");
        
        JLabel varietyshop__image1 = new JLabel(varietyshop_image);
        centerPanel.setOpaque(false);
		centerPanel.add(varietyshop__image1);
        
		return centerPanel;
	}

	private Component newEasthPanel() {
		// TODO Auto-generated method stub
		JPanel easthPanel = new JPanel();
		easthPanel.setPreferredSize(new Dimension(65,80));
		easthPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		JLabel v_commodity_explain = new JLabel("��Ʒ˵����");
		v_commodity_explain1 = new JLabel();
		v_commodity_explain2 = new JLabel();
		easthPanel.setOpaque(false);
		easthPanel.add(v_commodity_explain);
		easthPanel.add(v_commodity_explain1);
		easthPanel.add(v_commodity_explain2);
		return easthPanel;
	}
	
    //�ϲ�����
	private Component newSouthPanel() {
		// TODO Auto-generated method stub
		JPanel southPanel=new JPanel();
		southPanel.setPreferredSize(new Dimension(0,50));
		
        JButton varietyshop_gm= new JButton("��             ��");
        JButton varietyshop_lk= new JButton("��             ��");
        //varietyshop_gm.setBackground(new Color(0,199,140));
        varietyshop_gm.setPreferredSize(new Dimension(120,30));
        varietyshop_lk.setPreferredSize(new Dimension(120,30));
        
        southPanel.add(varietyshop_gm);
        southPanel.add(varietyshop_lk);
        southPanel.setOpaque(false);
        //����ť
        varietyshop_gm.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				DefaultButtonModel v_commodity_select1 = (DefaultButtonModel) v_commodity1.getModel();
				DefaultButtonModel v_commodity_select2 = (DefaultButtonModel) v_commodity2.getModel();
				if(v_commodity_select1.getGroup().isSelected(v_commodity_select1)) {
					//Ҫ���ӽ�Ǯ�ж�
					JOptionPane.showMessageDialog(varf, "��ҩ����ɹ���", "��ʾ", 1);
				}else if(v_commodity_select2.getGroup().isSelected(v_commodity_select2)){
					JOptionPane.showMessageDialog(varf, "ҩ�๺��", "��ʾ", 1);
				}else {
					JOptionPane.showMessageDialog(varf, "��û��ѡ����Ʒ��", "��ʾ", 1);
				}
			}
        	
        });
        //�뿪��ť
        varietyshop_lk.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int response = JOptionPane.showConfirmDialog(varf, "�Ƿ��뿪�ӻ��̣�", "��ʾ", JOptionPane.YES_NO_OPTION);
	        	if(response == 0) {
					System.out.println("�㰴������");
					varf.dispose();
					Cityframe.main();
				}else System.out.println("�㰴���˷�");
			}
        	
        });
		return southPanel;
	}
}
