package game;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import RPG.Player;

public class Cityframe {

	public static void main() {
		// TODO Auto-generated method stub
		Cityframe cityframe = new Cityframe();
		cityframe.initUI();
	}

	private void initUI() {
		// TODO Auto-generated method stub
		JFrame cityf = new JFrame();
		cityf.setTitle("ǿ��֮·");
		cityf.setSize(400,300);
		cityf.setLocation(400, 300);
		
		//���Բ���
		cityf.setLayout(null);
				
		JLabel cityf_jl1 = new JLabel("XX����");
		cityf_jl1.setSize(100, 30);
		
		ImageIcon image = new ImageIcon("./pic/shop.jpg");
		JLabel cityf_image = new JLabel(image);
		
		JButton cityf_jb1 = new JButton("���иſ�");
		JButton cityf_jb2 = new JButton("ס����Ϣ");
		JButton cityf_jb3 = new JButton("�� �� ��");
		JButton cityf_jb4 = new JButton("�� �� ��");
		JButton cityf_jb5 = new JButton("��    ��");
		
		cityf_jl1.setBounds(120, 5, 50, 50);
		cityf_image.setBounds(10, 20, 230, 250);
		cityf_jb1.setBounds(250, 40, 100, 30);
		cityf_jb2.setBounds(250, 80, 100, 30);
		cityf_jb3.setBounds(250, 120, 100, 30);
		cityf_jb4.setBounds(250, 160, 100, 30);
		cityf_jb5.setBounds(250, 220, 100, 30);
		
		cityf.add(cityf_jl1);
		cityf.add(cityf_image);
		
		cityf.add(cityf_jb1);
		cityf.add(cityf_jb2);
		cityf.add(cityf_jb3);
		cityf.add(cityf_jb4);
		cityf.add(cityf_jb5);
		
		cityf.setDefaultCloseOperation(3);
		cityf.setVisible(true);
		
		//���иſ�(Ҫ��һ���ָ�״̬)
        cityf_jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
                    String[] cmd = new String[]{"cmd.exe", "/c", "start",".\\pic\\city.txt"};
                    Runtime.getRuntime().exec(cmd);
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                	System.out.println("δ�ҵ��ļ���");
					e1.printStackTrace();
                }
			}
        	
        });
		
		//ס����Ϣ
		cityf_jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//������ѡ�ж��Ƿ�浵
				int response = JOptionPane.showConfirmDialog(cityf, "������Ҫ�浵�", "��ʾ", JOptionPane.YES_NO_OPTION);
				if(response == 0) {
					System.out.println("�㰴������");
					//�浵������δ��д��
					try {
						Player.playmodel_cd_w();
						JOptionPane.showMessageDialog(cityf, "�浵�ɹ�", "��ʾ", 1);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}else System.out.println("�㰴���˷�");
			}
			
		});
		
		//�ӻ���
		cityf_jb3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Varietyshop.main();
				cityf.dispose();
			}
			
		});
		
		//������
		cityf_jb4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Smithy.main();
				cityf.dispose();
			}
			
		});
		
		//�뿪
		cityf_jb5.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int response = JOptionPane.showConfirmDialog(cityf, "�Ƿ��뿪���У�", "��ʾ", JOptionPane.YES_NO_OPTION);
	        	if(response == 0) {
					System.out.println("�㰴������");
					cityf.dispose();
				}else System.out.println("�㰴���˷�");
			}
			
		});
	}

}
