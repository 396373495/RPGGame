package game;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import RPG.Player;
import page.Occupationpage;

public class Fightframe implements ActionListener{

	public static void main() throws IOException {
		// TODO Auto-generated method stub
		Fightframe fightframe = new Fightframe();
		fightframe.initUI();
	}

	public static JFrame figf;
	public static JLabel df_shengming;
	JLabel fig_my_zhiye;

	private void initUI() throws IOException {
		// TODO Auto-generated method stub
		figf = new JFrame();
		figf.setTitle("ǿ��֮·");
		figf.setSize(600,500);
		figf.setLocation(400, 300);
		
		//���Բ���
		figf.setLayout(null);
		
		//Ҫ��ְҵѡ�������ȡͷ��
		if(Occupationpage.OC.equals("����")) {
			fig_my_zhiye = new JLabel(Occupationpage.zhiye1);
		}else fig_my_zhiye = new JLabel(Occupationpage.zhiye2);
		
		Player.playmodel_my_r();
		
		JLabel my_shengming = new JLabel("����:"+(Player.my_HP-PDJframe.subtract));
		JLabel my_mofa = new JLabel("ħ��:"+Player.my_MP);
		JLabel my_gongji = new JLabel("����:"+Player.my_ATK);
		JLabel my_fangyu = new JLabel("����:"+Player.my_MTD);
		JLabel my_sudu = new JLabel("�ٶ�:"+Player.my_SPEED);

		fig_my_zhiye.setBounds(40, 20, 80, 80);
		my_shengming.setBounds(40, 120, 50, 20);
		my_mofa.setBounds(40, 150, 50, 20);
		my_gongji.setBounds(40, 180, 50, 20);
		my_fangyu.setBounds(40, 210, 50, 20);
		my_sudu.setBounds(40, 240, 50, 20);

		figf.add(fig_my_zhiye);
		figf.add(my_shengming);
		figf.add(my_mofa);
		figf.add(my_gongji);
		figf.add(my_fangyu);
		figf.add(my_sudu);

		//����ͷ��
		ImageIcon D_touxiang = new ImageIcon("./pic/d_touxiang.jpg");
		
		Player.playmodel_df_r();
		
		JLabel fig_d_touxiang = new JLabel(D_touxiang);
		df_shengming = new JLabel("����"+Player.df_HP);
		JLabel df_mofa = new JLabel("ħ��"+Player.df_MP);
		JLabel df_gongji = new JLabel("����"+Player.df_ATK);
		JLabel df_fangyu = new JLabel("����"+Player.df_MTD);
		JLabel df_sudu = new JLabel("�ٶ�"+Player.df_SPEED);
		
		fig_d_touxiang.setBounds(440, 20, 80, 80);
		df_shengming.setBounds(440, 120, 50, 20);
		df_mofa.setBounds(440, 150, 40, 20);
		df_gongji.setBounds(440, 180, 50, 20);
		df_fangyu.setBounds(440, 210, 50, 20);
		df_sudu.setBounds(440, 240, 50, 20);

		figf.add(fig_d_touxiang);
		figf.add(df_shengming);
		figf.add(df_mofa);
		figf.add(df_gongji);
		figf.add(df_fangyu);
		figf.add(df_sudu);
		
		JButton figf_gongji = new JButton("��  ��");
		JButton figf_daoju = new JButton("��  ��");
		JButton figf_jineng = new JButton("��  ��");
		JButton figf_taopao = new JButton("��  ��");
		
		figf_gongji.setBounds(80, 320, 200, 60);
		figf_daoju.setBounds(300, 320, 200, 60);
		figf_jineng.setBounds(80, 390, 200, 60);
		figf_taopao.setBounds(300, 390, 200, 60);
		
		figf.add(figf_gongji);
		figf.add(figf_daoju);
		figf.add(figf_jineng);
		figf.add(figf_taopao);	
	
		figf.setDefaultCloseOperation(3);
		figf.setVisible(true);
		
		//������ť��������Ҫ�Ӹ��������Ժ������͵������
		figf_gongji.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				try {
					
					PDJframe.GJUI();
					//ˢ��ҳ��
					Fightframe.figf.revalidate();
					System.out.println("9");
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
		
		//���߰�ť
		figf_daoju.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				PDJframe.DJUI();
			}
			
		});
		
		//���ܰ�ť
		figf_jineng.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				PDJframe.JNUI();
			}
			
		});
		
		//���ܰ�ť
		figf_taopao.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int response = JOptionPane.showConfirmDialog(figf, "ȷ������ս���", "��ʾ", JOptionPane.YES_NO_OPTION);
				if(response == 0) {
					System.out.println("�㰴������");
					try {
						PDJframe.TPUI();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}else {
					System.out.println("�㰴���˷�");
				}
			}

		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
