package RPG;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Player {

	public static List<String> my_model;
	public static List<String> df_model;
	private static File ctoFile1;
	private static File ctoFile2;
	public static Integer my_HP,my_MP,my_ATK,my_MTD,my_SPEED;
	public static int df_HP,df_MP,df_ATK,df_MTD,df_SPEED;
	
	public void play_my_model() {
		
	}
	
	
	public static void playmodel_my_r() throws IOException {
		//��ҵ�HP MP ���� ���� �ٶ� ���� ��Ǯ �ȼ�
		String txtline1 = null;
		my_model = new ArrayList<String>();
		ctoFile1 = new File(".\\pic\\my_model.txt");
		InputStreamReader rdCto1 = new InputStreamReader(new FileInputStream(ctoFile1));
		BufferedReader bfReader1 = new BufferedReader(rdCto1);
		while((txtline1 = bfReader1.readLine()) != null) {
			my_model.add(txtline1);
		}
		bfReader1.close();
		my_HP = Integer.parseInt(Player.my_model.get(0));
		my_MP = Integer.parseInt(Player.my_model.get(1));
		my_ATK = Integer.parseInt(Player.my_model.get(2));
		my_MTD = Integer.parseInt(Player.my_model.get(3));
		my_SPEED = Integer.parseInt(Player.my_model.get(4));
		System.out.println(my_model);
	}

	public static void playmodel_df_r() throws IOException {
		// TODO Auto-generated method stub
		//�з���HP MP ���� ���� �ٶ� ���� ��Ǯ �ȼ�
		String txtline2 = null;
		df_model = new ArrayList<String>();
		ctoFile2 = new File(".\\pic\\df_model.txt");
		InputStreamReader rdCto2 = new InputStreamReader(new FileInputStream(ctoFile2));
		BufferedReader bfReader2 = new BufferedReader(rdCto2);
		while((txtline2 = bfReader2.readLine()) != null) {
			df_model.add(txtline2);
		}
		bfReader2.close();
		df_HP = Integer.parseInt(Player.df_model.get(0));
		df_MP = Integer.parseInt(Player.df_model.get(1));
		df_ATK = Integer.parseInt(Player.df_model.get(2));
		df_MTD = Integer.parseInt(Player.df_model.get(3));
		df_SPEED = Integer.parseInt(Player.df_model.get(4));
		System.out.println(df_model);
	}

	public static void playmodel_cd_w() throws IOException {
		// TODO Auto-generated method stub
		
		BufferedReader my_model_cd = new BufferedReader(new FileReader(".\\pic\\my_model.txt"));
		BufferedWriter my_model_bc = new BufferedWriter(new FileWriter(".\\pic\\3.txt"));
		String lssj = null;
		
		while((lssj=my_model_cd.readLine()) != null) {
			my_model_bc.flush();
			my_model_bc.write(lssj);
			//
			my_model_bc.newLine();
		}
		my_model_cd.close();
		my_model_bc.close();
	}
	
}
