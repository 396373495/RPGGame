package page;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import datesj.Connection;
import game.GHframe;

public class Personal_information {

	public static void main() {
		// TODO Auto-generated method stub
		Personal_information p_info=new Personal_information();
        p_info.initUI();
	}

	private JFrame p_info_s;
	private JLabel my_touxiangzhiye,my_mingzizhiye;

	private void initUI() {
		// TODO Auto-generated method stub
		p_info_s = new JFrame();
		p_info_s.setTitle("ǿ��֮·");
		p_info_s.setSize(400,330);
		p_info_s.setLocation(400, 300);
		
		p_info_s.setLayout(new BorderLayout());
		p_info_s.add(newWestPanel(),BorderLayout.WEST);
		p_info_s.add(newEastPanel(),BorderLayout.EAST);
		
		p_info_s.setDefaultCloseOperation(3);
		p_info_s.setVisible(true);
	}

	private Component newWestPanel() {
		// TODO Auto-generated method stub
		JPanel westPanel=new JPanel();
		westPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
		westPanel.setPreferredSize(new Dimension(80,0));
		//��ȡ��ɫ��Ϣ
		Connection.connectPL_my_model();
		ImageIcon zhiye9 = new ImageIcon("./pic/zhiye1.jpg");
		ImageIcon zhiye10 = new ImageIcon("./pic/zhiye2.jpg");
		if(Connection.my_zhiye == 1) {
			my_touxiangzhiye = new JLabel(zhiye9);
			my_mingzizhiye = new JLabel("ְҵ��սʿ");
		}else {
			my_touxiangzhiye = new JLabel(zhiye10);
			my_mingzizhiye = new JLabel("ְҵ����ʦ");
		}
		JLabel my_shengming = new JLabel("����:"+Connection.my_HP);
		JLabel my_mofa = new JLabel("ħ��:"+(Connection.my_MP));
		JLabel my_gongji = new JLabel("����:"+(Connection.my_ATK));
		JLabel my_fangyu = new JLabel("����:"+(Connection.my_MTD));
		JLabel my_sudu = new JLabel("�ٶ�:"+(Connection.my_SPEED));
		JLabel my_exp = new JLabel("����:"+(Connection.my_EXP));
		JLabel my_gold = new JLabel("��Ǯ:"+(Connection.my_GOLD));
		JLabel my_lv = new JLabel("�ȼ�:"+(Connection.my_LV));
		
		westPanel.add(my_touxiangzhiye);
		westPanel.add(my_mingzizhiye);
		westPanel.add(my_shengming);
		westPanel.add(my_mofa);
		westPanel.add(my_gongji);
		westPanel.add(my_fangyu);
		westPanel.add(my_sudu);
		westPanel.add(my_exp);
		westPanel.add(my_gold);
		westPanel.add(my_lv);
		
		westPanel.setOpaque(false);
		return westPanel;
	}

	private Component newEastPanel() {
		// TODO Auto-generated method stub
		JPanel eastPanel=new JPanel();
		eastPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		eastPanel.setPreferredSize(new Dimension(105,0));
        JButton newgame = new JButton("�� �� Ϸ");
        JButton newgame_exit = new JButton("������Ϸ");
        eastPanel.setOpaque(false);
        eastPanel.add(newgame);
        eastPanel.add(newgame_exit);
        
        //����Ϸ��ť
        newgame.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				p_info_s.dispose();
				Occupationpage.main();
			}
        	
        });
        
        //������Ϸ��ť
        newgame_exit.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				p_info_s.dispose();
		        GHframe.main();
			}
        	
        });
        
        return eastPanel;
	}

}
