package game;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class Map extends JFrame {
	private static final long serialVersionUID = 1L;
	
	public static void main() throws IOException {
		new Map();
	}
	
	/**
	 1Ϊ�ݵأ���ɫ<br>
	 2Ϊ���ڣ�ǳ��<br>
	 4Ϊ��������ɽ<br>
	 5Ϊǽ�ڣ���׮<br>
	 1��2��ͨ����4��5����ͨ��
	 **/
	private Integer[][] maps = { { 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 5, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 1, 5, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 5, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 4 },
			                     { 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 },
			                     };

	//���ڴ�С
	private final int MAP_RANK = 15;
	private final int MAP_TRADE = 10;
	//�������,������ͼƬ������
	private final int BLOCK_WIDTH = 60;
	private final int BLOCK_HEIGHT = 60;
	//�������
	private Integer x;
	private Integer y;
	//����
	private Integer width;
	private Integer height;

	private Image user = ImageIO.read(new File(getFilePath("/user.png")));;
	private Image image1 = ImageIO.read(new File(getFilePath("/1.png")));
	private Image image2 = ImageIO.read(new File(getFilePath("/2.png")));
	private Image image4 = ImageIO.read(new File(getFilePath("/4.png")));
	private Image image5 = ImageIO.read(new File(getFilePath("/5.png")));

	public Map() throws IOException {
		//���λ�ó�ʼ��
		x = 2;
		y = 17;
		setTitle("�滭��ͼ");
		//��ȡ��Ļ����
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		width = MAP_RANK * BLOCK_WIDTH;
		height = MAP_TRADE * BLOCK_HEIGHT + 30;
		//ʹ���ھ���
		setBounds(screenSize.width / 2 - width / 2, screenSize.height / 2 - height / 2, width, height);

		setLayout(null);
		// ����Ĭ���˳���ʽ
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		// ���Ӱ�������
		addKeyListener(new KeyMoniton());
		setVisible(true);
	}

	// ����������
	private class KeyMoniton extends KeyAdapter {

		@Override
		public void keyPressed(KeyEvent e) {
			super.keyPressed(e);
			switch (e.getKeyCode()) {
			case KeyEvent.VK_UP:
				if (maps[x][y - 1] > 3) {
					return;
				}
				y -= 1;
				break;
			case KeyEvent.VK_DOWN:
				if (maps[x][y + 1] > 3) {
					return;
				}
				y += 1;
				break;
			case KeyEvent.VK_RIGHT:
				if (maps[x + 1][y] > 3) {
					return;
				}
				x += 1;
				break;
			case KeyEvent.VK_LEFT:
				if (maps[x - 1][y] > 3) {
					return;
				}
				x -= 1;
				break;
			}
			repaint();
		}

	}

	//�滭��ͼ�ķ�ʽ,���ҳ���ͼ���Ͻ�����,Ȼ�����Һ��·���ָ������
	@Override
	public void paint(Graphics g) {
		// Ĭ�ϴ�����߿�ʼ��
		int drawingx = 0;
		int drawingy = 0;
		int minx = MAP_RANK / 2;
		int miny = MAP_TRADE / 2;
		// ���һ�еĸ���Ϊż������������ٴμ�1
		int maxx = maps.length - minx - (MAP_RANK % 2 == 0 ? 0 : 1);
		// ����еĸ���Ϊż������������ٴμ�1
		int maxy = maps[0].length - miny - (MAP_TRADE % 2 == 0 ? 0 : 1);
		if (x > minx) {// �����ǰλ�ô�����Сλ�ã�������̶����м䣬��ʼxΪ��ǰλ�ü�ȥ��Сλ��
			drawingx = x - minx;
		}
		if (x > maxx) {// �����ǰλ�ô������λ������ʼxΪ�̶�ֵ
			drawingx = maxx - minx;
		}
		if (y > miny) {
			drawingy = y - miny;
		}
		if (y > maxy) {
			drawingy = maxy - miny;
		}
		Image image = null;
		for (int i = 0; i < MAP_RANK * MAP_TRADE; i++) {
			// ÿ�λ滭��һ�У�����������
			if (i > 0 && i % MAP_RANK == 0) {
				drawingy++;
			}
			image = getImage(maps[drawingx + i % MAP_RANK][drawingy]);
			g.drawImage(image, i % MAP_RANK * BLOCK_WIDTH, i / MAP_RANK * BLOCK_HEIGHT + 30, BLOCK_WIDTH, BLOCK_HEIGHT,
					null);
		}
		// ������
		if (x <= minx) {
			minx = x;
		}
		if (x > maxx) {
			minx = MAP_RANK - maps.length + x;
		}
		if (y < miny) {
			miny = y;
		}
		if (y > maxy) {
			miny = MAP_TRADE - maps[0].length + y;
		}
		g.drawImage(user, minx * BLOCK_WIDTH, miny * BLOCK_HEIGHT + 30, BLOCK_WIDTH, BLOCK_HEIGHT, null);
	}

	private Image getImage(Integer i) {
		switch (i) {
		case 1:
			return image1;
		case 2:
			return image2;
		case 4:
			return image4;
		case 5:
			return image5;

		default:
			return null;
		}
	}

	// ��ȡ�ļ�·��
	private String getFilePath(String fileName) {
		return Map.class.getResource(fileName).getPath();
	}

}
