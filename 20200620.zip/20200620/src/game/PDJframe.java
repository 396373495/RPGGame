package game;

import java.awt.FlowLayout;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import RPG.Player;

public class PDJframe {

	public static Integer subtract = 0;
	
	static void GJUI() throws IOException {
		// TODO Auto-generated method stub
		JFrame gjf = new JFrame();
		
		gjf.setTitle("������ʾ");
		gjf.setSize(500,120);
		gjf.setLocation(450, 520);
		
		Player.playmodel_my_r();
		Player.playmodel_df_r();
		
		//�˺��洢
		subtract = Player.my_ATK - Player.df_MTD;
		JLabel gjtext = new JLabel("��Ĺ��������"+subtract+"�˺�",JLabel.CENTER);
		
		System.out.println(subtract);
		
		//�˺�д���ı�
		//Player.playmodel_df_w();
		
		gjf.add(gjtext);
		
		gjf.setDefaultCloseOperation(2);
		gjf.setVisible(true);
	}

	static void DJUI() {
		// TODO Auto-generated method stub
        JFrame djf = new JFrame();
		
        djf.setTitle("����");
        djf.setSize(500,120);
        djf.setLocation(450, 520);
        
        JButton dj1 = new JButton("��");
        JButton dj2 = new JButton("��");
        JButton dj3 = new JButton("��");
        JButton dj4 = new JButton("��");
        JButton dj5 = new JButton("��");
        
        djf.setLayout(new FlowLayout());
        
        djf.add(dj1);
        djf.add(dj2);
        djf.add(dj3);
        djf.add(dj4);
        djf.add(dj5);
        
        djf.setDefaultCloseOperation(2);
        djf.setVisible(true);
        
        //jd1-5��ť�Ĵ���
	}

	static void JNUI() {
		// TODO Auto-generated method stub
        JFrame jnf = new JFrame();
		
        jnf.setTitle("����");
        jnf.setSize(500,120);
        jnf.setLocation(450, 520);
        
        JButton jn1 = new JButton("��");
        JButton jn2 = new JButton("��");
        JButton jn3 = new JButton("��");
        JButton jn4 = new JButton("��");
        JButton jn5 = new JButton("��");
        
        jnf.setLayout(new FlowLayout());
        
        jnf.add(jn1);
        jnf.add(jn2);
        jnf.add(jn3);
        jnf.add(jn4);
        jnf.add(jn5);
        
        jnf.setDefaultCloseOperation(2);
        jnf.setVisible(true);
	}

	static void TPUI() throws IOException {
		// TODO Auto-generated method stub
		int SJS = (int)(Math.random()*10);
		System.out.println(SJS);
		//���������жϣ�δ��ɣ�
		//���������5
		if(SJS > 5) {
			JOptionPane.showMessageDialog(null, "���ܳɹ�", "��ʾ", 1);
			Fightframe.figf.setVisible(false);
		}else {
			JOptionPane.showMessageDialog(null, "����ʧ��", "��ʾ", 2);
		}

	}

}
