package RPG;

public class LogUser {
	
	private static String tf_id3;
	private static String pf_paswd3;
	
	public static String getTf_id3() {
		return tf_id3;
	}
	public void setTf_id3(String tf_id3) {
		this.tf_id3 = tf_id3;
	}
	public static String getPf_paswd3() {
		return pf_paswd3;
	}
	public void setPf_paswd3(String pf_paswd3) {
		this.pf_paswd3 = pf_paswd3;
	}
}
