package game;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import datesj.Connection;

public class PDJframe implements ActionListener{

	public static Integer subtract = 0,subtract1 = 0;
	private static JFrame gjf;
	protected static int gjcs = 0;//�ж��Լ��Ƿ񹥻�
	
	static void GJUI() throws IOException {
		// TODO Auto-generated method stub
		//if(gjcs % 2 == 1) {
		//	SGJUI();
		//}else {
			gjf = new JFrame();
			
			gjf.setTitle("������ʾ");
			gjf.setSize(500,100);
			gjf.setLocation(450, 520);
			
			gjf.setLayout(new BorderLayout());
	        gjf.add(newNorthPanel(),BorderLayout.NORTH);
	        gjf.add(newCenterPanel(),BorderLayout.CENTER);
			
			//Player.playmodel_my_r();
			//Player.playmodel_df_r();
			
			gjf.setDefaultCloseOperation(2);
			gjf.setVisible(true);
			
			//�˺�д�����ݿ�
			//Player.playmodel_df_w();
			Connection.connectGJ_my();
			System.out.println("д��ɹ�");
		//}
	}
	
	static void SGJUI() throws IOException {
		// TODO Auto-generated method stub
		JFrame sgjf = new JFrame();
		
		sgjf.setTitle("������ʾ");
		sgjf.setSize(500,100);
		sgjf.setLocation(450, 520);
		
		sgjf.setLayout(null);
		
		//���˹����˺�
		subtract1 = Connection.df_ATK - Connection.my_MTD;
		JLabel sgjtext1 = new JLabel("�з��Ĺ��������"+subtract1+"�˺�",JLabel.CENTER);
		System.out.println(subtract1);
		
		JButton sgjf_jbu = new JButton("ȷ��");
		
		sgjtext1.setBounds(120, 0, 200, 20);
		sgjf_jbu.setBounds(170, 30, 100, 20);
		
		sgjf.add(sgjtext1);
		sgjf.add(sgjf_jbu);
		
		sgjf.setDefaultCloseOperation(2);
		sgjf.setVisible(true);
		
		//�˺�д�����ݿ�
		//Player.playmodel_df_w();
		Connection.connectGJ_df();
		System.out.println("д��ɹ�");
		
		sgjf_jbu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//�����жϡ�����ɱ
				sgjf.dispose();
				Fightframe.figf.dispose();
				try {
					Fightframe.main();
					Connection.connectSMPD();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
			
		});
	}

	private static Component newNorthPanel() {
		// TODO Auto-generated method stub
		JPanel northPanel=new JPanel();
		northPanel.setPreferredSize(new Dimension(0,20));
		//��ɫ�����˺�
		subtract = Connection.my_ATK - Connection.df_MTD;
		JLabel gjtext = new JLabel("��Ĺ��������"+subtract+"�˺�",JLabel.CENTER);
					
		System.out.println(subtract);
				
		northPanel.add(gjtext);
		northPanel.setOpaque(false);
		return northPanel;
	}

	private static Component newCenterPanel() {
		// TODO Auto-generated method stub
		JPanel centerPanel=new JPanel();
		centerPanel.setPreferredSize(new Dimension(0,20));
		JButton gjf_jbu = new JButton("ȷ��");
		centerPanel.add(gjf_jbu);
		centerPanel.setOpaque(false);
		
		//��ɱ�ж�
		gjf_jbu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//�����жϡ�����ɱ
				gjcs ++;
				gjf.dispose();
				Fightframe.figf.dispose();
				try {
					Fightframe.main();
					Connection.connectSMPD();
					if(GHframe.pigcount == 3) {
						Fightframe.figf.dispose();
					}else SGJUI();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
					
		});
		return centerPanel;
	}

	static void DJUI() {
		// TODO Auto-generated method stub
        JFrame djf = new JFrame();
		
        djf.setTitle("����");
        djf.setSize(500,120);
        djf.setLocation(450, 520);
        
        JButton dj1 = new JButton("��");
        JButton dj2 = new JButton("��");
        JButton dj3 = new JButton("��");
        JButton dj4 = new JButton("��");
        JButton dj5 = new JButton("��");
        
        djf.setLayout(new FlowLayout());
        
        djf.add(dj1);
        djf.add(dj2);
        djf.add(dj3);
        djf.add(dj4);
        djf.add(dj5);
        
        djf.setDefaultCloseOperation(2);
        djf.setVisible(true);
        
        //jd1-5��ť�Ĵ���
	}

	static void JNUI() {
		// TODO Auto-generated method stub
        JFrame jnf = new JFrame();
		
        jnf.setTitle("����");
        jnf.setSize(500,120);
        jnf.setLocation(450, 520);
        
        JButton jn1 = new JButton("��");
        JButton jn2 = new JButton("��");
        JButton jn3 = new JButton("��");
        JButton jn4 = new JButton("��");
        JButton jn5 = new JButton("��");
        
        jnf.setLayout(new FlowLayout());
        
        jnf.add(jn1);
        jnf.add(jn2);
        jnf.add(jn3);
        jnf.add(jn4);
        jnf.add(jn5);
        
        jnf.setDefaultCloseOperation(2);
        jnf.setVisible(true);
	}

	static void TPUI() throws IOException {
		// TODO Auto-generated method stub
		int SJS = (int)(Math.random()*10);
		System.out.println(SJS);
		//���������жϣ�δ��ɣ�
		//���������5
		if(SJS > 5) {
			JOptionPane.showMessageDialog(Fightframe.figf, "���ܳɹ�", "��ʾ", 1);
			if(GHframe.pigcount == 2) {
				Fightframe.figf.setVisible(false);
				//GHframe.ghf_1.setVisible(true);
				GHframe.pigcount = 1;
			}else {
				Fightframe.figf.setVisible(false);
				Map.main();
			}
		}else {
			JOptionPane.showMessageDialog(Fightframe.figf, "����ʧ��", "��ʾ", 2);
			SGJUI();
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
