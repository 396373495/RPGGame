package game;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.DefaultButtonModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import datesj.Connection;

public class Smithy {

	public static void main() {
		// TODO Auto-generated method stub
		Smithy smif = new Smithy();
		smif.initUI();
	}

	private JLabel s_commodity_explain1,s_commodity_explain2,s_commodity_explain3;
	private JRadioButton s_commodity1;
	private JRadioButton s_commodity2;
	private JFrame smif;
	public static int ssale1 = 20;
	protected int ssale2 = 99999;

	private void initUI() {
		// TODO Auto-generated method stub
		smif = new JFrame();
		smif.setTitle("ǿ��֮·");
		smif.setSize(500,400);
		smif.setLocation(400, 300);
		
		//�߿򲼾ֹ���������
		smif.setLayout(new BorderLayout());
        smif.add(newNorthPanel(),BorderLayout.NORTH);
        smif.add(newWesthPanel(),BorderLayout.WEST);
        smif.add(newCenterPanel(),BorderLayout.CENTER);
        smif.add(newEasthPanel(),BorderLayout.EAST);
        smif.add(newSouthPanel(),BorderLayout.SOUTH);
		
		smif.setDefaultCloseOperation(3);
		smif.setVisible(true);
	}

	private Component newNorthPanel() {
		// TODO Auto-generated method stub
		JPanel northPanel = new JPanel();
		JLabel biaoti = new JLabel("������");
        biaoti.setForeground(new Color(0,255,0));
        biaoti.setFont(new Font("",Font.BOLD,30));
        biaoti.setHorizontalAlignment(JLabel.CENTER);
       
        northPanel.setOpaque(false);
        
        northPanel.add(biaoti);
        
        return northPanel;
	}

	private Component newWesthPanel() {
		// TODO Auto-generated method stub
		JPanel westPanel = new JPanel();
		//����С
		westPanel.setPreferredSize(new Dimension(50,80));
		westPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		JLabel commodity_catalog = new JLabel("��Ʒ��");
		s_commodity1 = new JRadioButton("ľ��");
		s_commodity2 = new JRadioButton("����");
		ButtonGroup s_commodity = new ButtonGroup(); 
		s_commodity.add(s_commodity1);
		s_commodity.add(s_commodity2);
		westPanel.setOpaque(false);
		westPanel.add(commodity_catalog);
		westPanel.add(s_commodity1);
		westPanel.add(s_commodity2);
		
		s_commodity1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				s_commodity_explain1.setText("ATK+1");
				s_commodity_explain2.setText("������Ȥ");
				s_commodity_explain3.setText("�ۼ�:"+ssale1);
			}
			
		});
		
		s_commodity2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				s_commodity_explain1.setText("ATK+10");
				s_commodity_explain2.setText("�ȽϷ���");
				s_commodity_explain3.setText("�ۼ�:"+ssale2);
			}
			
		});

		return westPanel;
	}

	private Component newCenterPanel() {
		// TODO Auto-generated method stub
		JPanel centerPanel = new JPanel();
		centerPanel.setPreferredSize(new Dimension(0,0));
		
		ImageIcon smithy_image = new ImageIcon("./pic/sd2.jpg");
        
        JLabel smithy_image1 = new JLabel(smithy_image);
        centerPanel.setOpaque(false);
		centerPanel.add(smithy_image1);
        
		return centerPanel;
	}

	private Component newEasthPanel() {
		// TODO Auto-generated method stub
		JPanel easthPanel = new JPanel();
		easthPanel.setPreferredSize(new Dimension(65,80));
		easthPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
		JLabel s_commodity_explain = new JLabel("��Ʒ˵����");
		s_commodity_explain1 = new JLabel();
		s_commodity_explain2 = new JLabel();
		s_commodity_explain3 = new JLabel();
		easthPanel.setOpaque(false);
		easthPanel.add(s_commodity_explain);
		easthPanel.add(s_commodity_explain1);
		easthPanel.add(s_commodity_explain2);
		easthPanel.add(s_commodity_explain3);
		return easthPanel;
	}

	private Component newSouthPanel() {
		// TODO Auto-generated method stub
		JPanel southPanel=new JPanel();
		southPanel.setPreferredSize(new Dimension(0,50));
		
        JButton smithy_gm= new JButton("��             ��");
        JButton smithy_lk= new JButton("��             ��");
        Connection.connectPL_my_model();
        JLabel jqxs = new JLabel("��Ǯ��"+Connection.my_GOLD);
        //smithy_gm.setBackground(new Color(0,199,140));
        smithy_gm.setPreferredSize(new Dimension(120,30));
        smithy_lk.setPreferredSize(new Dimension(120,30));
        jqxs.setPreferredSize(new Dimension(120,30));
        
        southPanel.add(jqxs);
        southPanel.add(smithy_gm);
        southPanel.add(smithy_lk);
        southPanel.setOpaque(false);
      //����ť
        smithy_gm.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				DefaultButtonModel s_commodity_select1 = (DefaultButtonModel) s_commodity1.getModel();
				DefaultButtonModel s_commodity_select2 = (DefaultButtonModel) s_commodity2.getModel();
				if(s_commodity_select1.getGroup().isSelected(s_commodity_select1)) {
					//��Ҫ���ӽ�Ǯ�ж�
					if(Connection.my_GOLD > ssale1) {
						Connection.connectkcjq();
						JOptionPane.showMessageDialog(smif, "ľ������ɹ���", "��ʾ", 1);
						smif.dispose();
						Smithy.main();
					}
				}else if(s_commodity_select2.getGroup().isSelected(s_commodity_select2)){
					if(Connection.my_GOLD > ssale1) {
						Connection.connectkcjq();
						JOptionPane.showMessageDialog(smif, "��������", "��ʾ", 1);
						smif.dispose();
						Smithy.main();
					}
				}else {
					JOptionPane.showMessageDialog(smif, "��û��ѡ����Ʒ��", "��ʾ", 1);
				}
			}
        	
        });
      //�뿪��ť
        smithy_lk.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int response = JOptionPane.showConfirmDialog(smif, "�Ƿ��뿪�����̣�", "��ʾ", JOptionPane.YES_NO_OPTION);
	        	if(response == 0) {
					System.out.println("�㰴������");
					smif.dispose();
					Cityframe.main();
				}else System.out.println("�㰴���˷�");
			}
        	
        });
		return southPanel;
	}

}
