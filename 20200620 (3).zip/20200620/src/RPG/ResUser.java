package RPG;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import datesj.Connection;

public class ResUser {

	public static void main() {
		// TODO Auto-generated method stub
		ResUser resuser = new ResUser();
		resuser.initUI();
	}

	private JFrame res;
	static JTextField res_id;
	private JPasswordField res_paswd1,res_paswd2;

	private void initUI() {
		// TODO Auto-generated method stub
		res = new JFrame();
		res.setTitle("ǿ��֮·");
		res.setSize(400,300);
        res.setLocation(400, 300);
        
        setbackground(res);
        
        res.setLayout(new BorderLayout());
        res.add(newNorthPanel(),BorderLayout.NORTH);
        res.add(newWestPanel(),BorderLayout.WEST);
        res.add(newSouthPanel(),BorderLayout.SOUTH);
        res.add(newCenterPanel(),BorderLayout.CENTER);
        
        res.setDefaultCloseOperation(2);//1�����أ�2�����ز��ͷţ�3��ֱ�ӹر�
        res.setVisible(true);
	}
	
	//�û��������롢��֤�����չʾ
	private Component newCenterPanel() {
		// TODO Auto-generated method stub
    	JPanel centerPanel = new JPanel();
    	//����һ����������ʽ���ֹ���������
        centerPanel.setLayout(new FlowLayout(FlowLayout.LEFT));

        JLabel res_Reg=new JLabel("�û���");
        res_id=new JTextField();
        res_id.setPreferredSize(new Dimension(180,25));
        res_id.setText("");
        
        JLabel res_Pwd1=new JLabel("����");
        res_paswd1=new JPasswordField();
        res_paswd1.setPreferredSize(new Dimension(180,25));
        res_paswd1.setText("");
        
        JLabel res_Pwd2=new JLabel("ȷ������");
        res_paswd2=new JPasswordField();
        res_paswd2.setPreferredSize(new Dimension(180,25));
        res_paswd2.setText("");
        //�û�����
        centerPanel.add(res_id);
        centerPanel.add(res_Reg);
        //�����
        centerPanel.add(res_paswd1);
        centerPanel.add(res_Pwd1);
        //��֤�����
        centerPanel.add(res_paswd2);
        centerPanel.add(res_Pwd2);
        //͸��
        centerPanel.setOpaque(false);
        return centerPanel;
	}

	//��½ע�ᰴť��ʵ��
	private Component newSouthPanel() {
		// TODO Auto-generated method stub
		JPanel southPanel=new JPanel();
		southPanel.setPreferredSize(new Dimension(0,50));
		
        JButton res_bu= new JButton(" ǰ �� �� ½ ");
        JButton res_zc= new JButton("ע             ��");
        //res_bu.setBackground(new Color(0,199,140));
        res_bu.setPreferredSize(new Dimension(120,30));
        res_zc.setPreferredSize(new Dimension(120,30));
        
        southPanel.add(res_bu);
        southPanel.add(res_zc);
        southPanel.setOpaque(false);
        //ǰ����½��ť
        res_bu.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				res.dispose();
				LoginUser.main();
			}
        	
        });
        //ע�ᰴť
        res_zc.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String res_id2=res_id.getText();
		        String res_paswd3=new String(res_paswd1.getPassword());
		        LogUser user = new LogUser();
		        user.setRes_id3(res_id2);
		        user.setRes_paswd4(res_paswd3);
		        if(res_paswd1.equals(res_paswd2)) {
		        	//ע�ᴫ�����ݿ�
			        Connection.connectZC();
			        System.out.println(LogUser.getRes_id3()+"���ݳɹ�");
		        }else {
		        	JOptionPane.showMessageDialog(res, "�������벻��ͬ��", "�������", JOptionPane.QUESTION_MESSAGE);
		        	res_id.setText("");
		        	res_paswd1.setText("");
		        	res_paswd2.setText("");
		        }
		        	
			}
        	
        });
        
        return southPanel;
	}
	
	//���ñ������Ĵ�С��������������������ģ��
	private Component newNorthPanel() {
		// TODO Auto-generated method stub
		JPanel northPanel=new JPanel();
	    northPanel.setPreferredSize(new Dimension(0,100));
	    JLabel biaoti=new JLabel("�û�ע��");
	    biaoti.setForeground(new Color(0,255,0));
	    biaoti.setFont(new Font("",Font.BOLD,30));
	    biaoti.setHorizontalAlignment(JLabel.CENTER);
	    northPanel.add(biaoti);
	    northPanel.setOpaque(false);
	    return northPanel;
	}
		
	//�����������Ĵ�С����������������ͷ��ģ��
	private Component newWestPanel() {
		// TODO Auto-generated method stub
		JPanel westPanel=new JPanel();
	    westPanel.setPreferredSize(new Dimension(105,0));
	    westPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
	    ImageIcon touxiang2=new ImageIcon("./pic/touxiang2.jpg");
	    JLabel jlabelImage=new JLabel(touxiang2);
	    westPanel.setOpaque(false);
	    westPanel.add(jlabelImage);
	    return westPanel;
	}
	
	//��������������������ģ��
		@SuppressWarnings("deprecation")
		private void setbackground(JFrame res) {
			// TODO Auto-generated method stub
			ImageIcon bg3=new ImageIcon("./pic/bg2.jpg");
			JLabel jlb=new JLabel(bg3);
			jlb.setBounds(0, 0, bg3.getIconWidth(), bg3.getIconHeight());
			res.getLayeredPane().add(jlb,new Integer(Integer.MIN_VALUE));
	        JPanel contentPanel=(JPanel)res.getContentPane();
	        contentPanel.setOpaque(false);
		}
}
