package datesj;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

import RPG.LogUser;
import RPG.LoginUser;
import game.Fightframe;
import game.GHframe;
import game.PDJframe;
import game.Varietyshop;
import page.Homepage;

public class Connection{
	
    public static int my_HP,my_MP,my_ATK,my_MTD,my_SPEED,my_EXP,my_GOLD,my_LV,my_HPMAX,my_zhiye;
    public static int df_HP,df_MP,df_ATK,df_MTD,df_SPEED,df_EXP,df_GOLD;
	private static int a = 0;

    //�з�����
    public static void connectPL_df_model() {
    	try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	Statement stmt = null;
		ResultSet rs = null;
		try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_select = "select * from df_model";
			rs = stmt.executeQuery(sql_select);
			while (rs.next()) {
				df_HP = rs.getInt(1);
				df_MP = rs.getInt(2);
				df_ATK = rs.getInt(3);
				df_MTD = rs.getInt(4);
				df_SPEED = rs.getInt(5);
				df_EXP = rs.getInt(6);
				df_GOLD = rs.getInt(7);
				
				System.out.println(df_HP+"\t"+df_MP+"\t"+df_ATK+"\t"+df_MTD+"\t"+df_SPEED+"\t"+df_EXP+"\t"+df_GOLD);
			}
		}catch (Exception e1) {
			System.out.print("get data error!");
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    //��ɫ����
	public static void connectPL_my_model() {
    	try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	Statement stmt = null;
		ResultSet rs = null;
		try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_select = "select * from my_model";
			rs = stmt.executeQuery(sql_select);
			while (rs.next()) {
				my_HP = rs.getInt(1);
				my_MP = rs.getInt(2);
				my_ATK = rs.getInt(3);
				my_MTD = rs.getInt(4);
				my_SPEED = rs.getInt(5);
				my_EXP = rs.getInt(6);
				my_GOLD = rs.getInt(7);
				my_LV = rs.getInt(8);
				my_HPMAX = rs.getInt(9);
				my_zhiye = rs.getInt(10);
				System.out.println(my_HP+"\t"+my_MP+"\t"+my_ATK+"\t"+my_MTD+"\t"+my_SPEED+"\t"+my_EXP+"\t"+my_GOLD+"\t"+my_LV+"\t"+my_HPMAX+"\t"+my_zhiye);
			}
		}catch (Exception e1) {
			System.out.print("get data error!");
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
	
	//��½��֤
	public static void connectDL() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Statement stmt = null;
		ResultSet rs = null;
		try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_select = "select user from loginus where user='"+LogUser.getTf_id3()+"' and password = '"+LogUser.getPf_paswd3()+"'";
		    rs = stmt.executeQuery(sql_select);
		    if (rs.next()) {
		    	System.out.println("������ȷ��ת��������!");
		    	LoginUser.jf.setVisible(false);
		    	Homepage.main();
		    }else {
		    	JOptionPane.showMessageDialog(LoginUser.jf, "�������ֵ����", "��¼����", JOptionPane.QUESTION_MESSAGE);
		    	LoginUser.tf_id.setText("");
		    	LoginUser.pf_paswd.setText("");
		    }
		}catch (Exception e1) {
			System.out.print("get data error!");
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}
	
	//ע��
	public static void connectZC() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    String username9 = LogUser.getRes_id3();
	    String password9 = LogUser.getRes_paswd4(); 
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_insert = "insert into loginus values('"+username9+"','"+password9+"')";
		    count9 = stmt.executeUpdate(sql_insert);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}

	//ʤ����ȡ����ͽ��
    public static void connectHS() {
    	try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update my_model set EXP='"+(Connection.my_EXP+Connection.df_EXP)+"', GOLD='"+(Connection.my_GOLD+Connection.df_GOLD)+"'";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
	
    //�ҷ�����
    public static void connectGJ_my() {
    	try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update df_model set HP='"+(Connection.df_HP - PDJframe.subtract)+"'";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //�з�����
    public static void connectGJ_df() {
    	try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update my_model set HP='"+(Connection.my_HP - PDJframe.subtract1)+"'";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    //�����ж�
    public static void connectSMPD() {
    	//�����ж�
		connectPL_my_model();
		connectPL_df_model();
		if(my_HP < 1) {
			JOptionPane.showMessageDialog(Fightframe.figf, "���������������״̬��", "��ʾ", 1);
			Fightframe.figf.dispose();
			System.out.println("��������");
		}
		if(df_HP < 1) {
			JOptionPane.showMessageDialog(Fightframe.figf, "���ܵз������exp:"+Connection.df_EXP+";gold"+Connection.df_GOLD, "��ʾ", 1);
			connectHS();
			//�����ж�
			connectPL_my_model();
			if(Connection.my_EXP > Connection.my_LV*30 || Connection.my_EXP == Connection.my_LV*30) {
				a  = Connection.my_EXP/(Connection.my_LV*30);
				System.out.println(a);
				JOptionPane.showMessageDialog(null, "��ϲ��������:LV"+Connection.my_LV, "��ʾ", 1);
				connectsj();
			}
			connectres();
			GHframe.pigcount = 3;
			System.out.println("�з�����");
		}
		System.out.println("���й��ж���");
    }

    //����Ѫ����ԭ
	public static void connectres() {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update df_model set HP=60";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}
    
	//����
	public static void connectsj() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update my_model set LV='"+(Connection.my_LV + a)+"', HPMAX='"+(Connection.my_HPMAX+Connection.my_LV*10)+"', MP='"+(Connection.my_MP+Connection.my_LV*10)+"', ATK='"+(Connection.my_ATK+Connection.my_LV*10)+"', MTD='"+(Connection.my_MTD+Connection.my_LV*2)+"', SPEED='"+(Connection.my_SPEED+Connection.my_LV)+"'";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		    connectres1();
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}
	
	//��ɫ����ֵ��ԭ
	public static void connectres1() {
		connectPL_my_model();
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update df_model set HP='"+Connection.my_HPMAX+"'";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}
	
	//�۳���Ǯ
	public static void connectkcjq() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update my_model set GOLD='"+(my_GOLD-Varietyshop.sale1)+"'";
			
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}

    //�浵
	public static void connectCD() {
		connectPL_my_model();
    	try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update my_model set EXP='"+Connection.my_EXP+"', GOLD='"+(Connection.my_GOLD)+"', LV='"+(Connection.my_LV)+"', HP='"+(Connection.my_HPMAX)+"', MP='"+(Connection.my_MP)+"', ATK='"+(Connection.my_ATK)+"', MTD='"+(Connection.my_MTD)+"', SPEED='"+(Connection.my_SPEED)+"'";
			
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //ѡ��սʿʱ�����ĳ�ʼ����
	public static void connectzhanshi() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
        Connection conn = null;
	    Statement stmt = null;
	    try {
			java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update my_model set zhiye=1, HPMAX=50, EXP=0, GOLD=0, LV=1, HP=50, MP=10, ATK=40, MTD=20, SPEED=10";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
            //�ر���Դ
            if(stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
			if(conn != null) {
                try {
                    ((ResultSet) conn).close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
	}

	//��ʦ
	public static void connectfashi() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
		    // TODO Auto-generated catch block
			e.printStackTrace();
		}
		int count9 = 0;
	    Connection conn = null;
	    Statement stmt = null;
	    try {
	     	java.sql.Connection connect = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/rpggame","root","2533174");
			stmt = connect.createStatement();
			String sql_update = "update my_model set zhiye=2, HPMAX=30, EXP=0, GOLD=0, LV=1, HP=30, MP=50, ATK=50, MTD=10, SPEED=8";
		    count9 = stmt.executeUpdate(sql_update);
		    System.out.print(count9);
		}catch (Exception e1) {
		    e1.printStackTrace();
		}finally {
	           //�ر���Դ
	           if(stmt != null) {
	               try {
	                   stmt.close();
	               } catch (SQLException e) {
	                   e.printStackTrace();
	               }
	           }
			   if(conn != null) {
	               try {
	                   ((ResultSet) conn).close();
	               } catch (SQLException e) {
	                   e.printStackTrace();
	               }
	           }
	     }
	}
}