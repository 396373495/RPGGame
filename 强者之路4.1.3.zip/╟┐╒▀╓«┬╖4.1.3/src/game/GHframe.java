package game;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import datesj.Connection;
import page.Perinfo_frame;

public class GHframe implements ActionListener{
	
	//�������
	static Integer x = 1;
	static Integer y = 18;

	public static void main() {
		// TODO Auto-generated method stub
		GHframe ghframe = new GHframe();
		ghframe.initUI();
	}

	public static int pigcount = 0;//�ӵ�����pigcountֵΪ1
	static JFrame ghf_1;

	private void initUI() {
		// TODO Auto-generated method stub
		ghf_1 = new JFrame();
		ghf_1.setTitle("ǿ��֮·");
		ghf_1.setSize(400,300);
		ghf_1.setLocation(400, 300);
		
		//���ý��汳��
		setbackground(ghf_1);
		
		//���Բ���
		ghf_1.setLayout(null);
		
		JLabel ghf_jl1 = new JLabel("��");
		ghf_jl1.setSize(100, 30);
		
		ImageIcon image = new ImageIcon("./pic/home.jpg");
		JLabel ghf_image = new JLabel(image);
	
		JButton ghf_jb0 = new JButton("�� �� �� Ϣ");
		JButton ghf_jb1 = new JButton("�鿴������");
		JButton ghf_jb2 = new JButton("��     ��");//(�浵)
		JButton ghf_jb3 = new JButton("��     ��");
		JButton ghf_jb4 = new JButton("�� ȥ �� ��");
		
		ghf_jb0.setContentAreaFilled(false);
		ghf_jb1.setContentAreaFilled(false);
		ghf_jb2.setContentAreaFilled(false);
		ghf_jb3.setContentAreaFilled(false);
		ghf_jb4.setContentAreaFilled(false);
		
		ghf_jb0.setForeground(Color.blue);
		ghf_jb1.setForeground(Color.blue);
		ghf_jb2.setForeground(Color.blue);
		ghf_jb3.setForeground(Color.yellow);
		ghf_jb4.setForeground(Color.yellow);
		
		//ghf_jb0.setBorderPainted(false);
		
		ghf_jl1.setBounds(120, 5, 50, 50);
		ghf_image.setBounds(10, 20, 230, 250);
		ghf_jb0.setBounds(250, 30, 100, 30);
		ghf_jb1.setBounds(250, 80, 100, 30);
		ghf_jb2.setBounds(250, 130, 100, 30);
		ghf_jb3.setBounds(250, 180, 100, 30);
		ghf_jb4.setBounds(250, 230, 100, 30);
		
		ghf_1.add(ghf_jl1);
		ghf_1.add(ghf_image);
		
		ghf_1.add(ghf_jb0);
		ghf_1.add(ghf_jb1);
		ghf_1.add(ghf_jb2);
		ghf_1.add(ghf_jb3);
		ghf_1.add(ghf_jb4);
		
		ghf_1.setDefaultCloseOperation(3);
		ghf_1.setVisible(true);
		
		//������Ϣ��ť
		ghf_jb0.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				ghf_1.dispose();
				Perinfo_frame.main();
			}
			
		});
		
		//�鿴������
		ghf_jb1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				JOptionPane.showMessageDialog(ghf_1, "��������Ҫȥ����ɱͷ����", "������ʾ", 1);
				pigcount = 1;
			}
			
		});
		
		//����(�浵)
		ghf_jb2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//������ѡ�ж��Ƿ�浵
				int response = JOptionPane.showConfirmDialog(ghf_1, "�Ƿ�Ҫ��Ϣ��", "��ʾ", JOptionPane.YES_NO_OPTION);
				if(response == 0) {
					System.out.println("�㰴������");
					//Player.playmodel_cd_w();
					Connection.connectres1();//Ѫ������
					Connection.connectCD();//�浵
					JOptionPane.showMessageDialog(ghf_1, "˯���汥��", "��ʾ", 1);
				}else System.out.println("�㰴���˷�");
			}
			
		});
		
		//����
		ghf_jb3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(pigcount == 1) {
					int response = JOptionPane.showConfirmDialog(ghf_1, "��������С��������ʼս����", "��ʾ", JOptionPane.YES_NO_OPTION);
					if(response == 0) {
						System.out.println("�㰴������");
						JOptionPane.showMessageDialog(ghf_1, "��ʼս��", "��ʾ", 1);
						try {
							//ghf_1.setVisible(false);
							pigcount = 2;
							Fightframe.main();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}else System.out.println("�㰴���˷�");
				}else JOptionPane.showMessageDialog(ghf_1, "����ȥɢ���ˣ����������ɣ�", "��ʾ", 1);
			}
			
		});
		
		//��ȥ����
		ghf_jb4.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(pigcount == 3) {
					try {
						ghf_1.setVisible(false);
						Map.main();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}else JOptionPane.showMessageDialog(ghf_1, "��������û����أ���", "��ʾ", 1);
			
			}
		});
	}

	private void setbackground(JFrame ghf_12) {
		// TODO Auto-generated method stub
		ImageIcon bg3=new ImageIcon("./pic/bg5.jpg");
		JLabel jlb=new JLabel(bg3);
		jlb.setBounds(0, 0, bg3.getIconWidth(), bg3.getIconHeight());
		ghf_1.getLayeredPane().add(jlb,new Integer(Integer.MIN_VALUE));
        JPanel contentPanel=(JPanel)ghf_1.getContentPane();
        contentPanel.setOpaque(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
