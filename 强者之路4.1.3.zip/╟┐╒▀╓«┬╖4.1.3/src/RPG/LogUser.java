package RPG;

public class LogUser {
	
	private static String tf_id3;
	private static String pf_paswd3;
	private static String res_id3;
	private static String res_paswd4;
	
	public static String getTf_id3() {
		return tf_id3;
	}
	public void setTf_id3(String tf_id3) {
		LogUser.tf_id3 = tf_id3;
	}
	public static String getPf_paswd3() {
		return pf_paswd3;
	}
	public void setPf_paswd3(String pf_paswd3) {
		LogUser.pf_paswd3 = pf_paswd3;
	}
	
	public static String getRes_id3() {
		return res_id3;
	}
	public void setRes_id3(String res_id3) {
		LogUser.res_id3 = res_id3;
	}
	public static String getRes_paswd4() {
		return res_paswd4;
	}
	public void setRes_paswd4(String res_paswd4) {
		LogUser.res_paswd4 = res_paswd4;
	}

}
